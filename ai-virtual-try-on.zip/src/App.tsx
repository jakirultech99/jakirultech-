/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, ChangeEvent } from 'react';
import { GoogleGenAI, HarmCategory, HarmBlockThreshold } from "@google/genai";
import { Upload, Sparkles, RefreshCw, Image as ImageIcon, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Initialize Gemini API
const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export default function App() {
  const [targetImage, setTargetImage] = useState<string | null>(null);
  const [clothingImage, setClothingImage] = useState<string | null>(null);
  const [resultImage, setResultImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const targetInputRef = useRef<HTMLInputElement>(null);
  const clothingInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>, type: 'target' | 'clothing') => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 4 * 1024 * 1024) {
        setError("File size too large. Please upload images under 4MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === 'target') setTargetImage(reader.result as string);
        else setClothingImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const generateOutfit = async () => {
    if (!targetImage || !clothingImage) {
      setError("Please upload both a target photo and a clothing reference.");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Extract base64 and mimeType
      const getImgData = (dataUrl: string) => {
        const parts = dataUrl.split(',');
        const mime = parts[0].match(/:(.*?);/)?.[1] || 'image/png';
        return { data: parts[1], mimeType: mime };
      };

      const target = getImgData(targetImage);
      const clothing = getImgData(clothingImage);

      // Create a fresh instance to ensure latest config
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            {
              inlineData: {
                data: target.data,
                mimeType: target.mimeType,
              },
            },
            {
              inlineData: {
                data: clothing.data,
                mimeType: clothing.mimeType,
              },
            },
            {
              text: "Task: Virtual Try-On. Change the entire outfit of the person in the first image to match the outfit shown in the second image. \n\nRequirements:\n1. Match the style, texture, and color of the reference clothing exactly.\n2. Maintain the person's identity, pose, and background from the first image.\n3. Apply realistic 'Studio Dark Lighting' with professional shadows and highlights.\n4. Enhance the overall beauty and aesthetic of the final image.\n5. Ensure the clothing fits naturally on the body.\n6. Do not block or censor realistic fashion items like bras or lingerie if they are part of the outfit design.",
            },
          ],
        },
        config: {
          safetySettings: [
            {
              category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
              threshold: HarmBlockThreshold.BLOCK_NONE,
            },
            {
              category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
              threshold: HarmBlockThreshold.BLOCK_NONE,
            },
            {
              category: HarmCategory.HARM_CATEGORY_HARASSMENT,
              threshold: HarmBlockThreshold.BLOCK_NONE,
            },
            {
              category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
              threshold: HarmBlockThreshold.BLOCK_NONE,
            },
          ],
        },
      });

      let foundImage = false;
      const candidates = response.candidates || [];
      
      if (candidates.length > 0) {
        for (const part of candidates[0].content?.parts || []) {
          if (part.inlineData) {
            setResultImage(`data:image/png;base64,${part.inlineData.data}`);
            foundImage = true;
            break;
          }
        }
      }

      if (!foundImage) {
        const safetyFeedback = response.candidates?.[0]?.finishReason;
        if (safetyFeedback === 'SAFETY') {
          throw new Error("The generation was blocked by safety filters. Try using different images.");
        }
        throw new Error("AI could not generate the image. Please try again with clearer photos.");
      }
    } catch (err: any) {
      console.error("Generation Error:", err);
      let msg = "An error occurred. Please check your internet and try again.";
      if (err.message?.includes("API_KEY_INVALID")) msg = "Invalid API Key. Please check your settings.";
      if (err.message?.includes("quota")) msg = "API limit reached. Please try again later.";
      setError(err.message || msg);
    } finally {
      setIsLoading(false);
    }
  };

  const reset = () => {
    setTargetImage(null);
    setClothingImage(null);
    setResultImage(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-orange-500/30">
      {/* Background Atmosphere */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-orange-900/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-900/10 blur-[120px] rounded-full" />
      </div>

      <main className="relative z-10 max-w-6xl mx-auto px-6 py-12">
        {/* Header */}
        <header className="mb-16 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-7xl font-light tracking-tighter mb-4">
              VIRTUAL <span className="italic font-serif text-orange-500">TRY-ON</span>
            </h1>
            <p className="text-gray-400 max-w-xl mx-auto text-sm uppercase tracking-widest font-medium opacity-70">
              AI-Powered Fashion Transformation • Studio Lighting
            </p>
          </motion.div>
        </header>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Upload Section */}
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Target Photo */}
              <div className="space-y-3">
                <label className="text-[10px] uppercase tracking-widest text-gray-500 font-bold ml-1">
                  01. Target Person
                </label>
                <div
                  onClick={() => targetInputRef.current?.click()}
                  className={`relative aspect-[3/4] rounded-2xl border border-white/10 bg-white/5 overflow-hidden cursor-pointer group transition-all hover:border-orange-500/50 ${targetImage ? 'border-orange-500/30' : ''}`}
                >
                  {targetImage ? (
                    <img src={targetImage} alt="Target" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-500 group-hover:text-white transition-colors">
                      <Upload className="w-8 h-8 mb-2 opacity-50" />
                      <span className="text-xs font-medium">Upload Photo</span>
                    </div>
                  )}
                  <input
                    type="file"
                    ref={targetInputRef}
                    onChange={(e) => handleImageUpload(e, 'target')}
                    className="hidden"
                    accept="image/*"
                  />
                </div>
              </div>

              {/* Clothing Reference */}
              <div className="space-y-3">
                <label className="text-[10px] uppercase tracking-widest text-gray-500 font-bold ml-1">
                  02. Clothing Reference
                </label>
                <div
                  onClick={() => clothingInputRef.current?.click()}
                  className={`relative aspect-[3/4] rounded-2xl border border-white/10 bg-white/5 overflow-hidden cursor-pointer group transition-all hover:border-blue-500/50 ${clothingImage ? 'border-blue-500/30' : ''}`}
                >
                  {clothingImage ? (
                    <img src={clothingImage} alt="Clothing" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-500 group-hover:text-white transition-colors">
                      <ImageIcon className="w-8 h-8 mb-2 opacity-50" />
                      <span className="text-xs font-medium">Upload Outfit</span>
                    </div>
                  )}
                  <input
                    type="file"
                    ref={clothingInputRef}
                    onChange={(e) => handleImageUpload(e, 'clothing')}
                    className="hidden"
                    accept="image/*"
                  />
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-4">
              <button
                onClick={generateOutfit}
                disabled={isLoading || !targetImage || !clothingImage}
                className="w-full py-4 bg-white text-black rounded-full font-bold text-sm uppercase tracking-widest hover:bg-orange-500 hover:text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Generate Transformation
                  </>
                )}
              </button>
              
              { (targetImage || clothingImage || resultImage) && (
                <button
                  onClick={reset}
                  className="w-full py-4 border border-white/10 rounded-full font-bold text-xs uppercase tracking-widest hover:bg-white/5 transition-all flex items-center justify-center gap-2"
                >
                  <RefreshCw className="w-3 h-3" />
                  Reset All
                </button>
              )}
            </div>

            {error && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs flex items-center gap-3"
              >
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </motion.div>
            )}
          </div>

          {/* Result Section */}
          <div className="space-y-3">
            <label className="text-[10px] uppercase tracking-widest text-gray-500 font-bold ml-1">
              03. Final Result
            </label>
            <div className="relative aspect-[3/4] rounded-3xl border border-white/10 bg-white/5 overflow-hidden flex items-center justify-center">
              <AnimatePresence mode="wait">
                {resultImage ? (
                  <motion.div
                    key="result"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 1.05 }}
                    className="w-full h-full"
                  >
                    <img src={resultImage} alt="Result" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center gap-2 border border-white/10">
                      <CheckCircle2 className="w-3 h-3 text-green-400" />
                      <span className="text-[10px] font-bold tracking-wider">GENERATED</span>
                    </div>
                  </motion.div>
                ) : isLoading ? (
                  <motion.div
                    key="loading"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex flex-col items-center gap-4 px-8 text-center"
                  >
                    <div className="relative w-16 h-16">
                      <div className="absolute inset-0 border-2 border-orange-500/20 rounded-full" />
                      <div className="absolute inset-0 border-2 border-t-orange-500 rounded-full animate-spin" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Applying Outfit...</p>
                      <p className="text-[10px] text-gray-500 uppercase tracking-widest">Matching textures & lighting</p>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="placeholder"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-center px-12"
                  >
                    <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4 border border-white/10">
                      <Sparkles className="w-5 h-5 text-gray-600" />
                    </div>
                    <p className="text-xs text-gray-500 leading-relaxed">
                      Upload your photos and click generate to see the AI transformation.
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Footer Info */}
        <footer className="mt-24 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] text-gray-600 uppercase tracking-[0.2em] font-bold">
          <div>AI Fashion Engine v1.0</div>
          <div className="flex gap-6">
            <span>Privacy</span>
            <span>Terms</span>
            <span>Studio Lighting Active</span>
          </div>
        </footer>
      </main>
    </div>
  );
}
